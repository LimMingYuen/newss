# Changelog

## 19.1.0 (2025-02-19)

### Implemented enhancements

- take over change from version 18.5.0

### Breaking Changes

- please go to breaking changes block in version 18.5.0 (2025-02-19)

## 19.0.0 (2025-01-22)

### Implemented enhancements

| Work Item | Type | Description |
| -- | -- | -- |
| [100138](https://tfs.intra.infineon.com/tfs/FactoryIntegration/ART%20MSI/_workitems/edit/100138) | Story | WMFL - Angular 19 update |

### Breaking Changes

- all components|pipes|directive are now standalone (but NgModule is still supported)

```ts
  // old in main.ts
  import { AppModule } from './app/app.module';

  platformBrowserDynamic().bootstrapModule(AppModule)

  // new in main.ts
  bootstrapApplication(AppComponent, {
      providers: [
          importProvidersFrom(BrowserModule, IfxUfeModule, AppRoutingModule),
          provideAnimations()
      ]
  })
  .catch(err => console.error(err));

  // new with iSecure in main.ts
  bootstrapApplication(AppComponent, {
  providers: [
    importProvidersFrom(
      BrowserModule,
      IfxUfeModule,
      AppRoutingModule,
      IfxAuthorizationModule.forRootWithProvider(httpLoaderFactoryISecure)
    ),
    provideAnimations(),
  ],
}).catch(err => console.error(err));

```

- @angular/material:^19.0.0
- @angular-isecure-authorization:^19.0.0 # when the ufe app needs iSecure claims security
- angular-auth-oidc-client:^19.0.0

## 18.5.0 (2025-02-19)

### Implemented enhancements

- enable uFE standalone or the Shell to run in a iframe
  - for enabling running a ufe in a iframe you have to all your ufe with _ifxEnvironment=self

  ```ts
    @Component({
    selector: 'app-test-app1',
    standalone: true,
    imports: [IfxUfeModule],
    templateUrl: './test-app1.component.html',
    styleUrl: './test-app1.component.scss'
  })
  export class TestApp1Component {
    link = environment.ufeLinks?.app1+'?_ifxEnvironment=self';
  }
  ```

  ```html
    <iframe [src]="link | ifxUfeSafeUrl"> </iframe>
  ```

### Breaking Changes

- add new JWT counter component inside the header and auth component
  - can be diabled via hideJwtCounter

    ```html
    <ifx-ufe-header [title]="title" (logout)="onLogout()" [hideJwtCounter]="true">
    ```

- change silent refresh background loop from JavaScript setTimeout to rxjs interval
  - silent refresh only active in uFE which use ifx-header component (it enabled also in case of header is not visible in a SELF hosted uFE app)
  - all other uFE have to add ifx-ufe-auth-refresh component

  ```html
    <div class="invisible">
     <ifx-ufe-auth-refresh></ifx-ufe-auth-refresh>
    </div>
  ```

## 18.4.0 (2025-02-04)

### Implemented enhancements

| Work Item | Type | Description |
| -- | -- | -- |
| [136003](https://tfs.intra.infineon.com/tfs/FactoryIntegration/ART%20MSI/_workitems/edit/136003) | Story | Support of MES UI (uFE's) Angular 18 update |

### Breaking Changes

- AbstractShell
  - add Observales
    - appDeSelected$
      - emits when an application was deselected
    - appSelected$
      - emits when an application was selected
    - currentLanguage$
      - emits when the language changed in the shell
    - appList$
      - emits when appliction collection changed
    - layout$
      - emits when layout changed in the sehll
  - add readonly Signals
    - layout
      - the current active layout
    - activeApps
      - the current active applications in the shell
    - appList
      - the current application list in the shell
    - currentLanguage
      - the current language in the shell

- AbstractShellView
  - contains now all properties for getting shell applications, language and layout

<!-- CHANGELOG SPLIT MARKER -->

## 18.3.0 (2025-01-03)

### Implemented enhancements

| Work Item | Type | Description |
| -- | -- | -- |
| [136036](https://tfs.intra.infineon.com/tfs/FactoryIntegration/ART%20MSI/_workitems/edit/136036/) | Story | SPIKE - Monorepo with Nx |

### Breaking Changes

- remove importing of BrowserModule,BrowserAnimationsModule in ifx-ufe.modules.ts
- add import CommonModule in ifx-ufe.modules.ts
- add UfeUnauthorizedComponent
- change RouterModule.forRoot(routes) to RouterModule.forChild(routes) in ifx-ufe.modules.ts
- add AbstractShellView class for handling only ufe apps
- flexbox align-items=center for containers in 'ifx-ufe-header' component
- clear session storage after 500 ms in logout component
- add environment config value useFrontEndJson true|false|undefined
  - true ... read frontEnd.json
  - false ... skip reading frontEnd.json
  - undefined ... Default value == true
- AbstractShell
  - remove
    - onAppSelect --> it is handled by library internally itself
    - handleOpenUfe --> it is handled by library internally itself
  - activeApps is now only readonly --> it is handled by library internally itself
  - setting layout and language in localstorge should be not more used

### Bugfixes

- update reading/checking existing token
  - move from ufeMessageListener directive to login and silentRefresh component

<!-- CHANGELOG SPLIT MARKER -->

## 18.2.0 (2024-10-28)

### Implemented enhancements

| Work Item | Type | Description |
| -- | -- | -- |
| [107428](https://tfs.intra.infineon.com/tfs/FactoryIntegration/ART%20MSI/_workitems/edit/107428) | Story | WMFL - uFE as modal dialog in another uFE (WAC use case + Business UX) |

### Breaking Changes

- move all items from localStorage to sessionStorage
- add to all sessionStorage items a prefix ifx-ufe-
- remove saving activeApps in sessionStorage

<!-- CHANGELOG SPLIT MARKER -->

## 18.1.0 (2024-10-10)

### Implemented enhancements

| Work Item | Type | Description |
| -- | -- | -- |
| [111842](https://tfs.intra.infineon.com/tfs/FactoryIntegration/ART%20MSI/_workitems/edit/111842) | Story | WMFL - Use Single Retrieval Endpoint of the WRL |

### Breaking Changes

- abstract-shell.ts
  - remove empty OnInit function
  - currentApps/activeApps --> activeApps: signal<AppDescription[]>;
  - activeApps$ --> Observable<AppDescription[]> (have to be used only in construction context)
  - layout: BehaviorSubject<string> --> signal<string>('ProductionView');
  - isAuthenticated: AuthStatus --> is now a getter
  - storing 'scenariosLoaded' in store and not in session storage

- front-end-discovery.service.ts
  - add: public async getAppsAsync(): Promise<AvailableUfe>
  - getApps(): Observable<AvailableUfe> (have to be used only in construction context)

<!-- CHANGELOG SPLIT MARKER -->

## 18.0.0 (2024-09-09)

### Implemented enhancements

| Work Item | Type | Description |
| -- | -- | -- |
| [60835](https://tfs.intra.infineon.com/tfs/FactoryIntegration/ART%20MSI/_sprints/taskboard/PIA%20-%200%20Internal/ART%20MSI/2024/PI3/Sprint%203.2?workitem=60835) | Story | WMFL - Angular 18 update |

<!-- CHANGELOG SPLIT MARKER -->
## 17.5.0 (12.11.2024)

### Breaking Changes

```typescript
class IfxUfeAuthGuard

old: canActivate(): Observable<boolean>
new: async canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Promise<boolean>

```

<!-- CHANGELOG SPLIT MARKER -->
## 17.4.2 (01.11.2024)

### Hotfix

- fix not loading in time of wrl.json file

### Bugfix

- IfxUfeAuthGuard responses Observable<boolean> instead of boolean and allows routing with query string parameters

<!-- CHANGELOG SPLIT MARKER -->
## 17.4.1 (23.10.2024)

### Hotfix

- open a uFE in a new tab or browser window with header again

<!-- CHANGELOG SPLIT MARKER -->
## 17.4.0 (16.10.2024)

### Implemented enhancements

- provide also idToken in AuthToken class

```typescript
  class AuthToken {
    kerberos: any;
    credentials: any;
    idToken?: IdAuthToken;
  }

  class IdAuthToken {
    kerberos: any;
    credentials: any;
  }

```

<!-- CHANGELOG SPLIT MARKER -->

## 17.3.1 (14.10.2024)

### Implemented enhancements

### Hotfix

- enable sending message to this.window.parent when an uFE was open by a self hosted uFE in an other tab

<!-- CHANGELOG SPLIT MARKER -->

## 17.3.0 (2024-09-26)

### Implemented enhancements

| Work Item | Type | Description |
| -- | -- | -- |
| [116695](https://tfs.intra.infineon.com/tfs/FactoryIntegration/ART%20MSI/_sprints/taskboard/PIA%20-%200%20Internal/ART%20MSI/2024/PI3/Sprint%203.3?workitem=116695) | Bug | WMFL - Version 17.2.x cannot open dialog via PeerMessage |
| [121117](https://tfs.intra.infineon.com/tfs/FactoryIntegration/ART%20MSI/_sprints/taskboard/PIA%20-%200%20Internal/ART%20MSI/2024/PI3/Sprint%203.3?workitem=121117) | Bug | WMFL - Token not passed to browser dialog |
| [105362](https://tfs.intra.infineon.com/tfs/FactoryIntegration/ART%20MSI/_sprints/taskboard/PIA%20-%200%20Internal/ART%20MSI/2024/PI3/Sprint%203.1?workitem=105362) | Story | WMFL - Token not passed to browser dialog |

### Breaking Changes

- beforeunload --> execute 'onLogout()'

<!-- CHANGELOG SPLIT MARKER -->

## 17.2.1 (2024-09-09)

### Implemented enhancements

| Work Item | Type | Description |
| -- | -- | -- |
| [119436](https://tfs.intra.infineon.com/tfs/FactoryIntegration/ART%20MSI/_sprints/taskboard/PIA%20-%200%20Internal/ART%20MSI/2024/PI3/Sprint%203.2?workitem=119436) | Bug | WMFL - "dialog-modal" influences other iframes css in shell |

<!-- CHANGELOG SPLIT MARKER -->

## 17.2.0 (2024-07-12)

### Implemented enhancements

| Work Item | Type | Description |
| -- | -- | -- |
| [23252](https://tfs.intra.infineon.com/tfs/FactoryIntegration/ART%20MSI/_sprints/taskboard/PIA%20-%200%20Internal/ART%20MSI/2024/PI2/Sprint%202.4) | Story | WMFL - Method to get HostProfileName from JWT (MHA) |

<!-- CHANGELOG SPLIT MARKER -->

## 17.1.1 (2024-06-28)

### Implemented enhancements

- fix sizing of user icon
- fix wrong overlap of authentication mnu

<!-- CHANGELOG SPLIT MARKER -->

## 17.1.0 (2024-06-25)

### Implemented enhancements

| Work Item | Type | Description |
| -- | -- | -- |
| [24144](https://tfs.intra.infineon.com/tfs/FactoryIntegration/ART%20MSI/_workitems/edit/24144/) | Story | Configurable Titlebar/Header (IOT Sensor Framework) |

<!-- CHANGELOG SPLIT MARKER -->

## 17.0.0 (2024-06-06)

### Implemented enhancements

| Work Item | Type | Description |
| -- | -- | -- |
| [30666](https://tfs.intra.infineon.com/tfs/FactoryIntegration/ART%20MSI/_sprints/taskboard/PIA%20-%200%20Internal/ART%20MSI/2024/PI2/Sprint%202.2?workitem=30666) | Story | WWMFL - Angular 17 library update |

## 16.4.3 (2024-05-17)

### Implemented enhancements

- bring new browser window in focus

<!-- CHANGELOG SPLIT MARKER -->

## 16.4.1 (2024-04-30)

### Implemented enhancements

| Work Item | Type | Description |
| -- | -- | -- |
|  | Story | JWT auth refresh for Kerberos |
|  | Story | add Browser/Modal Dialog feature  |

### Breaking Changes

- renanme target in openWebResource from 'dialog' to 'dialog-modal'/'dialog-brower'
  - dialog-modal === dialog-modal
  - dialog-broser === open new browser window
