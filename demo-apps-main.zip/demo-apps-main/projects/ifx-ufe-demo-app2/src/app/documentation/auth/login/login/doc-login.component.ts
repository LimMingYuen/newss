import { Component } from '@angular/core';

@Component({
  selector: 'ifx-ufe-demo-login',
  imports: [],
  templateUrl: './doc-login.component.html',
  styleUrl: './doc-login.component.scss',
})
export class DocLoginComponent {}
