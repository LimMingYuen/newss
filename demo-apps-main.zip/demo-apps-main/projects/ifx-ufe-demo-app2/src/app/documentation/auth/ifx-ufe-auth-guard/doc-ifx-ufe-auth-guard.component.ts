import { Component } from '@angular/core';

@Component({
  selector: 'ifx-ufe-demo-ifx-ufe-auth-guard',
  imports: [],
  templateUrl: './doc-ifx-ufe-auth-guard.component.html',
  styleUrl: './doc-ifx-ufe-auth-guard.component.scss',
})
export class DocIfxUfeAuthGuardComponent {}
