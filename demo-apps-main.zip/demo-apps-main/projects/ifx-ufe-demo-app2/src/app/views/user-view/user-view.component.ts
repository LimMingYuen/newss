import { Component } from '@angular/core';

@Component({
  selector: 'ifx-ufe-demo-user-view',
  imports: [],
  templateUrl: './user-view.component.html',
  styleUrl: './user-view.component.scss',
})
export class UserViewComponent {}
