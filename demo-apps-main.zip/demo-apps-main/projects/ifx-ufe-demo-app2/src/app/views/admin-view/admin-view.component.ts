import { Component } from '@angular/core';

@Component({
  selector: 'ifx-ufe-demo-admin-view',
  imports: [],
  templateUrl: './admin-view.component.html',
  styleUrl: './admin-view.component.scss',
})
export class AdminViewComponent {}
