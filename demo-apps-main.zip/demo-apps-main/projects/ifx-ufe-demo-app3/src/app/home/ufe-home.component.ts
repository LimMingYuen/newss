import { Component } from '@angular/core';

@Component({
  selector: 'ifx-ufe-demo-home',
  imports: [],
  templateUrl: './ufe-home.component.html',
  styleUrl: './ufe-home.component.scss',
})
export class UfeHomeComponent {}
