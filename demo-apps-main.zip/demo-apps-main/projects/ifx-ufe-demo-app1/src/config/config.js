window.wrlConfig = {
    env: 'stag', // test, stag, prod
    site: 'VIH200', // VIH300, DRS200, DRS300
    configPath: window.location.origin + '/assets/wrl.json'
};

window.logging = {
    logLevel : 0
};

window.useFrontEndJson = false;