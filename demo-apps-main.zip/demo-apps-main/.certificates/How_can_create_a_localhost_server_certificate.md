# How can I setup server ssl for Angular development server

## Follow these steps to set up the server certificate

1. **Trust the certificate:**
   Add localhost certificate by running `dotnet dev-certs https --trust`. This will make your system trust the localhost certificate for development purposes.

2. **Run `certmgr` in the console:**
   Begin by typing `certmgr` in your console. This will open the Certificate Manager, which is used to manage digital certificates on your system.

3. **Navigate to Own Certificates > Certificates:**
   In the Certificate Manager, navigate to the "Own Certificates" (Win10: "Personal") section and then go to "Certificates". This is where all your generated certificates are listed.

4. **Export Certificate via context menu 'all tasks' >  export**
   - click next button
   - select 'Yes, private key export'
   - select PKCS #12 (.PFX)
   - click next
   - select password
   - type your password
   - select AES256-SHA256
   - click next

5. **split the pfx file with help of openssl into cert and key file**
   - you can use git bash

   ```ts
    openssl pkcs12 -in <certname>.pfx -nocerts -out server.key.pem -nodes -passin pass:<your password>

    openssl pkcs12 -in <certname>.pfx -clcerts -nokeys -out server.crt.pem
   ```
