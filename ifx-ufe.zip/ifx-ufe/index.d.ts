/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="ifx-ufe" />
export * from './public-api';
