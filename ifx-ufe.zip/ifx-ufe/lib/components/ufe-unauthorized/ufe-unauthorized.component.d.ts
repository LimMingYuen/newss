import * as i0 from "@angular/core";
export declare class UfeUnauthorizedComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<UfeUnauthorizedComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UfeUnauthorizedComponent, "ifx-ufe-unauthorized", never, {}, {}, never, never, true, never>;
}
