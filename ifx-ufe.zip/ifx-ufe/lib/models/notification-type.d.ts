export declare enum NotificationType {
    Info = "info",
    Success = "success",
    Error = "error",
    Warning = "warning"
}
