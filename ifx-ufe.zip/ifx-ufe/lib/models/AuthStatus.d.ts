export declare class AuthStatus {
    kerberos: boolean;
    credentials: boolean;
    constructor(kerberos?: boolean, credentials?: boolean);
}
