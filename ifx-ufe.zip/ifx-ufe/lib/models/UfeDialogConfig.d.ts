export declare class UfeDialogConfig {
    width: string;
    height: string;
}
