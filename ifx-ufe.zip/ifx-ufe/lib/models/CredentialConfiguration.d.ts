export declare class CredentialConfiguration {
    kerberosLocation: string;
    credentialLocation: string;
}
