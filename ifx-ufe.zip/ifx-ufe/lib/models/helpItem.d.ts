export declare class HelpItem {
    ufeName: string;
    url: URL;
    constructor(name: string, uri: URL);
}
