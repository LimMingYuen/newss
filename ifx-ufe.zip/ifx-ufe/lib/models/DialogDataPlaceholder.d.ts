export declare class DialogDataPlaceholder {
    constructor();
}
