export declare enum AuthMode {
    Kerberos = 0,
    Credentials = 1,
    Ask = 2
}
