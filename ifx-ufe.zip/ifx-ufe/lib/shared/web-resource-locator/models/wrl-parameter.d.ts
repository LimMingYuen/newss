export declare class WRLParameter {
    name: string;
    description: string;
    constructor(_name: string, _description: string);
}
