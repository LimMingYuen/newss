export declare class InvalidTokenError extends Error {
}
