export interface JwtDecodeOptionsInterface {
    header?: boolean;
}
