export interface JwtHeaderInterface {
    typ?: string;
    alg?: string;
    kid?: string;
}
