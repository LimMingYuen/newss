import { AppDescription } from '../../../models/AppDescription';
/**
 * frontEnd.json content
 */
export declare class AvailableUfe {
    AvailableUfe: Array<AppDescription>;
}
