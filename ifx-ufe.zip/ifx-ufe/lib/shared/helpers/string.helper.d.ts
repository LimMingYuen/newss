/**
 * Trim char in string
 */
export declare function trimChar(value: string, charToRemove: string): string;
export declare function isNullOrUndefinedOrEmpty(value: string | undefined | null): boolean;
